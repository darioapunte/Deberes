// Mostrar la fecha actual
const fechaEl = document.getElementById("fecha");
const hoy = new Date();
const opciones = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
fechaEl.textContent = hoy.toLocaleDateString('es-ES', opciones);
